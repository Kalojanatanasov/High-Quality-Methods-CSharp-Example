﻿using System;

namespace Methods
{
    class Methods
    {
        static double CalculateTriangleArea(double sideA, double sideB, double sideC)
        {
            if (sideA <= 0 || sideB <= 0 || sideC <= 0)
            {
                throw new ArgumentOutOfRangeException("The sides of the triangle must be positive");
            }
            double semiPerimeter = (sideA + sideB + sideC) / 2;
            double triangleArea = Math.Sqrt(semiPerimeter * (semiPerimeter - sideA) * (semiPerimeter - sideB) * (semiPerimeter - sideC));
            return triangleArea;
        }

        static string ConvertDigitToDigitName(int digit)
        {
            if (digit == null)
            {
                throw new ArgumentNullException("The input of the number must be non-nullable type");
            }
            string str = string.Empty;
            switch (digit)
            {
                case 0: str="zero"; break;
                case 1: str="one"; break;
                case 2: str="two"; break;
                case 3: str="three"; break;
                case 4: str="four"; break;
                case 5: str="five"; break;
                case 6: str="six"; break;
                case 7: str="seven"; break;
                case 8: str="eight"; break;
                case 9: str="nine"; break;
                default: str = "The input must be digit not number or string"; break;
            }
            return str;
        }

        static int FindMaximumElementInArray(params int[] elements)
        {
            if (elements == null || elements.Length == 0)
            {
                throw new ArgumentNullException("The method can't be implemented on empty string");
            }

            int length = elements.Length;
            int maxElement = int.MinValue;
            for (int i = 1; i < length; i++)
            {
                if (elements[i] > maxElement)
                {
                    maxElement = elements[i];
                }
            }
            return maxElement;
        }

        static void PrintNumberOnConsole(double number, string formatOnConsole)
        {
            if (number == null)
            {
                throw new ArgumentNullException("The input of the number must be non-nullable type");
            }
            if (formatOnConsole == "f")
            {
                Console.WriteLine("{0:f2}", number);
            }
            else if (formatOnConsole == "%")
            {
                Console.WriteLine("{0:p0}", number);
            }
            else if (formatOnConsole == "r")
            {
                Console.WriteLine("{0,8}", number);
            }
            else
            {
                Console.WriteLine("{0}", number);
            }
        }

        static double CalcDistanceBetweenTwoPoints(double x1, double y1, double x2, double y2, 
            out bool isHorizontal, out bool isVertical)
        {
            if (x1 == null || x2 == null || y1 == null || y2 == null)
            {
                throw new ArgumentNullException("the point coordinates must not be null");
            }
            if (y1 == y2)
            {
                isHorizontal = true;
            }
            else
            {
                isHorizontal = false;
            }
            if (x1 == x2)
            {
                isVertical = true;
            }
            else
            {
                isVertical = false;
            }            

            double distance = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
            return distance;
        }

        static void Main()
        {
            double triangleArea = CalculateTriangleArea(3, 4, 5);
            Console.WriteLine(triangleArea);

            string digitName = ConvertDigitToDigitName(5);
            Console.WriteLine(digitName);

            int maxElement = FindMaximumElementInArray(5, -1, 3, 2, 14, 2, 3);
            Console.WriteLine(maxElement);

            PrintNumberOnConsole(1.3, "f");
            PrintNumberOnConsole(0.75, "%");
            PrintNumberOnConsole(2.30, "r");

            bool horizontalDistance, verticalDistance;
            double distanceBetweenPoinst = CalcDistanceBetweenTwoPoints(3, -1, 3, 2.5, out horizontalDistance, out verticalDistance);
            Console.WriteLine(distanceBetweenPoinst);
            Console.WriteLine("HorizontalDistance? " + horizontalDistance);
            Console.WriteLine("VerticalDistance? " + verticalDistance);
            
            Student peter = new Student() { FirstName = "Peter", LastName = "Ivanov" };
            peter.OtherInfo = "From Sofia, born at 17.03.1992";

            Student stella = new Student() { FirstName = "Stella", LastName = "Markova" };
            stella.OtherInfo = "From Vidin, gamer, high results, born at 03.11.1993";

            Console.WriteLine("{0} older than {1} -> {2}",
                peter.FirstName, stella.FirstName, peter.FirstStudentIsOlderThan(stella));
        }
    }
}
