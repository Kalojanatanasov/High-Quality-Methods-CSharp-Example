﻿using System;

namespace Methods
{
    class Student
    {
        private string firstName;
        private string lastName;
        private string otherInfo;

        public string FirstName 
        { 
            get
            {
                return firstName;
            }
            set
            {
                if (value == null || value == string.Empty) 
                {
                    throw new FormatException("the inputed first name must be string");
                }
                else
                {
                    firstName=value;
                }
            }
        }
        
        public string LastName 
        { 
            get
            {
                return lastName;
            }
            set
            {
                if (value == null || value == string.Empty)
                {
                    throw new FormatException("the inputed first name must be string");
                }
                else
                {
                    lastName=value;
                }
            }
        }

        public string OtherInfo
        {
            get
            {
                return otherInfo;
            }
            set
            {
                bool result;
                DateTime data;
                result = DateTime.TryParse((value.Substring(value.Length - 10)),out data);
                if (result == false)
                {
                    throw new FormatException("the last ten symbol must be in dateTime format DD.MM.YYYY");
                }
                else
                {
                    otherInfo = value;
                }
            }
        }

        public bool FirstStudentIsOlderThan(Student other)
        {
            DateTime firstDate =
                DateTime.Parse(this.OtherInfo.Substring(this.OtherInfo.Length - 10));
            DateTime secondDate =
                DateTime.Parse(other.OtherInfo.Substring(other.OtherInfo.Length - 10));
            return firstDate > secondDate;
        }
    }
}
